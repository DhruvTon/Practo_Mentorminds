<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Practo - @yield('title') Page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family= Corbel|Tahoma|Comic Neue|Lobster|Rubik|Heebo|Yanone Kaffeesatz|Prompt|Josefin Sans|Fjalla One|Kanit|Anton|VT323|Pacifico|Geo|Questrial|Inconsolata|Kanit|Anton|Poppins|Hammersmith One|Kalam|Josefin Sans|Teko|Montserrat Alternates|Handlee|Ropa Sans|Russo One|Bellota|Electrolize|Prompt|Lobster Two|Source Code Pro|Questrial|Do Hyeon|Acme|Righteous|Kanit|Baloo Bhai 2">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/258f31346d.js" crossorigin="anonymous"></script>
    <link rel="icon" href="https://pbs.twimg.com/profile_images/849341342224351238/cuaVqp5x_400x400.jpg"
          type="image/x-icon">
    <style>
        body {
            background-color: #D7BDE2;
        }

        div {
            margin: 0;
        }

        header img {
            border-radius: 10%;
        }

        .navbar-dark {
            background-color: #0EBFE9;
            padding: 0;
            color: black;
        }

        .navbar-brand {
            margin-left: 20px;
            font-size: 20px;
        }

        .nav-link {
            font-size: 15px;
        }

        #navigation .active {
            background-color: #ffffff;
            color: black;
        }

        #navigation .nav-link:hover {
            background-color: #000080;
            color: #ffffff;
        }

        ul {
            list-style-type: none;
            text-decoration: none;
            text-align: left;
        }

        a {
            color: black;
        }

            a:hover {
                color: black;
            }

        .container {
            margin-top: 50px;
        }

        #home {
            margin: 10px;
            border-radius: 10px;
            text-align: center;
            background-color: #87CEEB;
        }

            #home h2 {
                font-size: 3.0vh;
            }

            #home button {
                font-size: 20px;
                color: white;
                background-color: #009ACD;
            }

        #practo {
            background-color: rgba(0, 0, 128, 0.9);
            border-radius: 10px 0 0 10px;
        }

        @media only screen and (max-width: 768px) {
            #practo {
                height: 150px;
                border-radius: 10px 10px 0 0;
            }
        }

        #details {
            text-align: center;
            color: black;
        }

            #details #features, #details #advantages {
                background-color: #87CEEB;
            }

        #about div {
            padding: 20px;
            background-color: #87CEEB;
            font-family: Corbel;
        }

        #details #features, #details #advantages {
            margin: 10px;
        }

        #details h2, #about h2, #contact-us h2 {
            padding-top: 10px;
            font-size: 40px;
            font-family: Corbel;
        }

        #details p, #about p, #contact-us p {
            padding-top: 10px;
            font-size: 15px;
            font-family: Corbel;
            font-size: 3vh;
        }

        #about div {
            margin-bottom: 20px;
            text-align: center;
            color: black;
        }

        footer {
            margin-top: 50px;
            text-align: center;
            color: black;
            background-color: #0EBFE9;
            font-size: 2.5vh;
        }

        #address {
            text-align: left;
        }

            #address p {
                padding: 0;
                font-size: 2.75vh;
            }

        #quick-links h2 {
            padding: 10px 0 0 30px;
            font-size: 40px;
        }

        #quick-links ul {
            text-align: center;
        }

        #new-booking h2, #booking-details h2, #admin-login h2 {
            font-size: 40px;
            margin: 10px 0 10px 0;
            font-family: Corbel;
        }

        #new-booking, #booking-details, #admin-login {
            padding: 20px;
            background-color: #87CEEB;
            text-align: center;
            color: black;
            font-family: Corbel;
        }

        label {
            font-size: 15px;
        }

        #home {
            box-shadow: 5px 5px 10px #5f5f5f;
        }

        .btn {
            box-shadow: 3px 3px 6px #5f5f5f;
        }

        .form-control:hover {
            border: solid 2px white;
        }

        .form-control:focus {
            box-shadow: 0px 0px 10px 4px #00ff00;
        }

        .btn:hover {
            box-shadow: 5px 5px 10px #5f5f5f;
            border: solid 2px black;
        }

        #features, #advantages {
            position: relative;
            top: 15px;
        }

        #icon {
            width: 120px;
            height: 120px;
            position: relative;
            top: -60px;
        }

        #features h2, #advantages h2 {
            position: relative;
            top: -35px;
        }

        #features ul {
            position: relative;
            top: -10px;
            font-size: 3vh;
        }

        #advantages ul {
            position: relative;
            top: -10px;
            font-size: 2.75vh;
        }

        .glossy {
            border-radius: 10px;
            border: 1px solid #4864a9;
            -webkit-box-shadow: 5px 5px 10px #5f5f5f;
            box-shadow: 5px 5px 10px #5f5f5f;
            position: relative;
        }

            .glossy:before {
                content: "";
                display: block;
                position: absolute;
                left: 5px;
                background-color: #87CEEB;
            }
    </style>
    <header>
        <nav class="navbar fixed-top navbar-expand-md navbar-dark" id="navigation">
            <a class="navbar-brand" href="#">
                <img src="{{ URL::asset('images/logo.png')}}" height=30 width=30>
                Practo
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-content" aria-controls="navbar-content" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbar-content">
                <ul class="navbar-nav ml-auto" align="center">
                    <li class="nav-item">
                        <a class="nav-link" href="#home" style="padding-left: 10px;">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact-us" style="padding-left: 10px;">Contact Us</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="container">
        <div class="glossy" id="booking-details">
            <form method="post" action="new_booking" enctype="multipart/form-data">
                @csrf
                <div>
                    <h2>New Booking</h2>
                </div>
                <div class="row justify-content-around">
                    <div class="col-11 col-md-5">
                        <div class="row" style="padding-top: 15px;">
                            <label for="name">Name</label>
                        </div>
                        <div class="row">
                            <input class="form-control" id="name" name="name" type="text" placeholder="Name" value="{{old('name')}}">
                        </div>
                        @error('name')
                        <div class="row" style="padding: 10px 0 0 10px;">
                            <span style="color: red;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp{{$message}}</span>
                        </div>
                        @enderror
                    </div>
                    <div class="col-11 col-md-5">
                        <div class="row" style="padding-top: 15px;">
                            <label for="contact_number">Contact Number</label>
                        </div>
                        <div class="row">
                            <input class="form-control" id="contact_number" name="contact_number" type="text" placeholder="Contact Number" value="{{old('contact_number')}}">
                        </div>
                        @error('contact_number')
                        <div class="row" style="padding: 10px 0 0 10px;">
                            <span style="color: red;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp{{$message}}</span>
                        </div>
                        @enderror
                    </div>
                </div>
                <div class="row justify-content-around">
                    <div class="col-11 col-md-5">
                        <div class="row" style="padding-top: 15px;">
                            <label for="test">Select a Test(s)</label>
                        </div>
                        <div class="row">
                            <select class="form-control" id="test" name="test" type="text">
                                <option value="" selected>None</option>
                                @foreach($tests as $test)
                                <option value="{{$test->id}}" {{ (old('test') == $test->id) ? 'selected' : '' }}>{{$test->test_name}}</option>
                                @endforeach
                            </select>
                        </div>
                        @error('test')
                        <div class="row" style="padding: 10px 0 0 10px;">
                            <span style="color: red;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp{{$message}}</span>
                        </div>
                        @enderror
                    </div>
                    <div class="col-11 col-md-5">
                        <div class="row" style="padding-top: 15px;">
                            <label for="prescription">Upload Prescription</label>
                        </div>
                        <div class="row">
                            <input class="form-control" id="prescription" name="prescription" type="file">
                        </div>
                        @error('prescription')
                        <div class="row" style="padding: 10px 0 0 10px;">
                            <span style="color: red;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp{{$message}}</span>
                        </div>
                        @enderror
                    </div>
                </div>
                <div class="row justify-content-around">
                    <div class="col-11">
                        <div class="row" style="padding-top: 15px;">
                            <label for="lab">Select Lab</label>
                        </div>
                        <div class="row">
                            <select class="form-control" id="lab" name="lab" type="text">
                                <option value="" selected>None</option>
                                @foreach($labs as $lab)
                                <option value="{{$lab->id}}" {{ (old('lab') == $lab->id) ? 'selected' : '' }}>{{$lab->lab_name}}</option>
                                @endforeach
                            </select>
                        </div>
                        @error('lab')
                        <div class="row" style="padding: 10px 0 0 10px;">
                            <span style="color: red;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp{{$message}}</span>
                        </div>
                        @enderror
                        @if(Session::get('status'))
                        <div class="row" style="padding: 10px 0 0 10px;">
                            <span style="color: red;"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp{{Session::get('status')}}</span>
                        </div>
                        @endif
                    </div>
                </div>
                <div class="row justify-content-around" style="padding-top: 20px;">
                    <div class="col-4 col-sm-3">
                        <a class="form-control btn btn-danger" href="/">Cancel</a>
                    </div>
                    <div class="col-4 col-sm-3">
                        <button type="submit" class="form-control btn btn-success">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    @endsection
